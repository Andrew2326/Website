# TecnoDisegni - sito React full stack

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express

## Avvio rapido

### Backend
```bash
cd backend
npm install
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend: http://localhost:5173  
Backend: http://localhost:4000

## Funzioni incluse
- Landing page moderna per clienti
- Form richiesta disegni tecnici
- Tema chiaro/scuro
- Endpoint API POST `/api/requests`
- Base pronta per database, email o CRM

## Migliorie consigliate
- Upload file reale con Multer
- Invio email con Nodemailer
- Salvataggio su MongoDB o PostgreSQL
- Rate limiting e validazione avanzata
