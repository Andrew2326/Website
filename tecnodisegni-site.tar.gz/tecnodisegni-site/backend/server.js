import express from 'express'
import cors from 'cors'

const app = express()
const PORT = process.env.PORT || 4000

app.use(cors())
app.use(express.json())

app.get('/api/health', (req, res) => {
  res.json({ ok: true, message: 'API attiva' })
})

app.post('/api/requests', (req, res) => {
  const { name, email, details, company, phone, projectType, urgency, filesNote } = req.body || {}
  if (!name || !email || !details) {
    return res.status(400).json({ message: 'Compila almeno nome, email e dettagli richiesta.' })
  }
  const requestId = `REQ-${Date.now()}`
  return res.status(201).json({
    message: 'Richiesta registrata correttamente.',
    request: { requestId, company, name, email, phone, projectType, urgency, filesNote, details, createdAt: new Date().toISOString() }
  })
})

app.listen(PORT, () => {
  console.log(`Server avviato su http://localhost:${PORT}`)
})
