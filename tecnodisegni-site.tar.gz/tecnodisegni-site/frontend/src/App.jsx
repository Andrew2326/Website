import { useMemo, useState } from 'react'
import { FiArrowRight, FiCheckCircle, FiClock, FiFileText, FiGrid, FiMoon, FiPhone, FiSun, FiUploadCloud } from 'react-icons/fi'

const initialForm = {
  company: '',
  name: '',
  email: '',
  phone: '',
  projectType: 'Disegno meccanico',
  urgency: 'Standard',
  details: '',
  filesNote: ''
}

const services = [
  { title: 'Disegni 2D esecutivi', text: 'Tavole tecniche pulite, quotate e pronte per officina o produzione.' },
  { title: 'Modellazione e revisione', text: 'Aggiornamento disegni esistenti, correzioni e ottimizzazione documentazione.' },
  { title: 'Supporto rapido clienti', text: 'Canale semplice per inviare richieste, allegare note e ricevere risposta veloce.' }
]

const steps = [
  'Invio richiesta con specifiche e urgenza',
  'Valutazione tecnica e preventivo',
  'Conferma lavoro e avvio sviluppo disegni',
  'Consegna file finali e revisioni concordate'
]

export default function App() {
  const [theme, setTheme] = useState('light')
  const [form, setForm] = useState(initialForm)
  const [status, setStatus] = useState({ type: '', message: '' })
  const [loading, setLoading] = useState(false)
  const year = useMemo(() => new Date().getFullYear(), [])

  const onChange = (e) => {
    const { name, value } = e.target
    setForm((prev) => ({ ...prev, [name]: value }))
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setStatus({ type: '', message: '' })
    try {
      const response = await fetch('http://localhost:4000/api/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      })
      const data = await response.json()
      if (!response.ok) throw new Error(data.message || 'Errore durante l\'invio.')
      setStatus({ type: 'success', message: 'Richiesta inviata con successo. Ti ricontatterò al più presto.' })
      setForm(initialForm)
    } catch (error) {
      setStatus({ type: 'error', message: error.message || 'Invio non riuscito.' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={`app ${theme}`}>
      <a className="skip-link" href="#contenuto">Vai al contenuto</a>
      <header className="topbar">
        <div className="brand">
          <div className="logo" aria-hidden="true">
            <svg viewBox="0 0 64 64" fill="none">
              <path d="M10 46 31 14h22L32 50H10Z" stroke="currentColor" strokeWidth="4" strokeLinejoin="round" />
              <path d="M24 38h28" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
            </svg>
          </div>
          <div>
            <strong>TecnoDisegni</strong>
            <span>Richieste clienti</span>
          </div>
        </div>
        <nav className="nav">
          <a href="#servizi">Servizi</a>
          <a href="#processo">Processo</a>
          <a href="#contatto">Contatto</a>
          <button type="button" className="theme-btn" onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} aria-label="Cambia tema">
            {theme === 'light' ? <FiMoon /> : <FiSun />}
          </button>
        </nav>
      </header>

      <main id="contenuto">
        <section className="hero">
          <div className="hero-copy">
            <p className="eyebrow">Disegni tecnici conto terzi</p>
            <h1>Una pagina clienti chiara per ricevere richieste in modo rapido e professionale.</h1>
            <p className="hero-text">I tuoi clienti possono descrivere il progetto, indicare priorità, lasciare recapiti e inviarti una richiesta strutturata in pochi minuti.</p>
            <div className="hero-actions">
              <a href="#contatto" className="btn btn-primary">Invia richiesta <FiArrowRight /></a>
              <a href="#servizi" className="btn btn-secondary">Vedi servizi</a>
            </div>
            <div className="hero-points">
              <span><FiCheckCircle /> Risposta veloce</span>
              <span><FiFileText /> Richiesta ordinata</span>
              <span><FiClock /> Processo semplice</span>
            </div>
          </div>

          <aside className="hero-card" aria-label="Riepilogo servizi">
            <div className="mini-label">Ideale per</div>
            <h2>Clienti che devono richiedere tavole, revisioni o supporto tecnico.</h2>
            <ul>
              <li><FiGrid /> Disegni costruttivi e di officina</li>
              <li><FiUploadCloud /> Invio note e riferimenti progetto</li>
              <li><FiPhone /> Ricontatto via email o telefono</li>
            </ul>
          </aside>
        </section>

        <section id="servizi" className="section">
          <div className="section-head">
            <p className="eyebrow">Servizi</p>
            <h2>Frontend pensato per convertire, con UI pulita e leggibile.</h2>
          </div>
          <div className="cards">
            {services.map((service) => (
              <article className="card" key={service.title}>
                <h3>{service.title}</h3>
                <p>{service.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="processo" className="section process">
          <div className="section-head narrow">
            <p className="eyebrow">Processo</p>
            <h2>Un flusso semplice, così il cliente capisce subito cosa succede dopo.</h2>
          </div>
          <div className="timeline">
            {steps.map((step, index) => (
              <div className="timeline-item" key={step}>
                <span>{String(index + 1).padStart(2, '0')}</span>
                <p>{step}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="contatto" className="section contact-wrap">
          <div className="section-head narrow left">
            <p className="eyebrow">Contatto cliente</p>
            <h2>Modulo richiesta pronto per il backend.</h2>
            <p>Il form invia i dati a un endpoint API Express. Puoi collegarlo facilmente a email, database o CRM.</p>
          </div>

          <form className="contact-card" onSubmit={onSubmit}>
            <div className="form-grid">
              <label>Azienda<input name="company" value={form.company} onChange={onChange} placeholder="Nome azienda" /></label>
              <label>Nome referente<input name="name" value={form.name} onChange={onChange} placeholder="Mario Rossi" required /></label>
              <label>Email<input type="email" name="email" value={form.email} onChange={onChange} placeholder="cliente@email.it" required /></label>
              <label>Telefono<input name="phone" value={form.phone} onChange={onChange} placeholder="+39 ..." /></label>
              <label>Tipo progetto<select name="projectType" value={form.projectType} onChange={onChange}><option>Disegno meccanico</option><option>Disegno esecutivo</option><option>Revisione tavole</option><option>Supporto tecnico</option></select></label>
              <label>Urgenza<select name="urgency" value={form.urgency} onChange={onChange}><option>Standard</option><option>Urgente</option><option>Molto urgente</option></select></label>
            </div>
            <label>Dettagli richiesta<textarea name="details" value={form.details} onChange={onChange} rows="6" placeholder="Descrivi lavorazione, quote, formato richiesto, materiale, scadenza..." required /></label>
            <label>Note sugli allegati<input name="filesNote" value={form.filesNote} onChange={onChange} placeholder="Es. invio DWG, PDF o foto via email/WeTransfer" /></label>
            {status.message && <div className={`alert ${status.type}`} role="status">{status.message}</div>}
            <button className="btn btn-primary submit-btn" type="submit" disabled={loading}>{loading ? 'Invio in corso...' : 'Invia richiesta'} <FiArrowRight /></button>
          </form>
        </section>
      </main>

      <footer className="footer">
        <p>© {year} TecnoDisegni · Pagina clienti per disegni tecnici.</p>
      </footer>
    </div>
  )
}
